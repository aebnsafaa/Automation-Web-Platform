<?php
if ($_POST) {
    $_settings = get_option('wwo_settings');
    $_POST['general']['awp_validated'] = $_settings['general']['awp_validated'];
    update_option('wwo_settings', $_POST);
}

$settings = get_option('wwo_settings');
$general_tab = '';
$general_show = '';
$general_tab = 'active';
$general_show = '';
?>


<div class="wrap">
    <div class="container-otp">
        <div class="otp">
            <h1 class="form-title"><?php esc_html_e( 'Wawp OTP for Woocommerce Login & Register', 'awp' ); ?></h1>
            <div class="form-wrapper">
            <div class="tab-wrapper p-0">
                    <ul class="navbar">
                        <li class="nav-tab list-group-item m-0 pointer <?= $general_tab ?>" data-card="general"><?php esc_html_e( 'General', 'awp' ); ?></li>
                        <li class="nav-tab list-group-item m-0 pointer" data-card="login"><?php esc_html_e( 'Login', 'awp' ); ?></li>
                        <li class="nav-tab list-group-item m-0 pointer" data-card="register"><?php esc_html_e( 'Register', 'awp' ); ?></li>
                    </ul>
             <div class="pt-0">
                <form action="" method="POST" id="wwo_settings" class="<?= $general_show ?>">
                    <?php
                    include 'settings/general.php';
                    include 'settings/login.php';
                    include 'settings/register.php';
                    ?>
                    <button type="submit" class="button-primarywa submit"><?php esc_html_e( 'Save Settings', 'awp' ); ?></button>
                </form>
            </div>

            </div>
            <div class="info">
          	  <div class="info-body">
                          	      


    <p class="head"><a href="https://wawp.net" title="Wawp" target="_blank"><img style="width: 200px;" src="<?php echo WWO_URL . 'assets/img/wawp-logo.png' ?>"></a></p>
    
    <hr class="line">
        <div class="quick-links">
            
        <a href="https://wawp.net/docs/how-to-use/basic-account-settings/whatsapp-number-qr-connect/" target="_blank" class="quick-link">⚡How to Connect WhatsApp number to using Wawp QR code?</a>
        <a href="https://wawp.net/docs/third-party/wordpress-woocommerce/setup-general-otp-settings/" target="_blank" class="quick-link">🔗How to Link WooCommerce plugin using Instance ID</a>
        <a href="https://wawp.net/docs/third-party/wordpress-woocommerce/" target="_blank" class="quick-link">🗂️WAWP WooCommerce Plugin Docs</a>
        </div>

    <hr class="line">
		
		        <div class="help-items">
            <a href="https://wawp.net/docs/third-party/wordpress-woocommerce/setup-general-otp-settings/" target="_blank">
                <div class="help-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="help-icon"><path d="M12 6a3.939 3.939 0 0 0-3.934 3.934h2C10.066 8.867 10.934 8 12 8s1.934.867 1.934 1.934c0 .598-.481 1.032-1.216 1.626a9.208 9.208 0 0 0-.691.599c-.998.997-1.027 2.056-1.027 2.174V15h2l-.001-.633c.001-.016.033-.386.441-.793.15-.15.339-.3.535-.458.779-.631 1.958-1.584 1.958-3.182A3.937 3.937 0 0 0 12 6zm-1 10h2v2h-2z"></path><path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z"></path></svg>
                    <span><?php _e('Help center', 'awp'); ?></span>
                </div> 
            </a>

            <a href="https://www.youtube.com/@wawpapp" target="_blank">
                <div class="help-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="help-icon"><path d="M18 7c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v10c0 1.103.897 2 2 2h12c1.103 0 2-.897 2-2v-3.333L22 17V7l-4 3.333V7zm-1.998 10H4V7h12l.001 4.999L16 12l.001.001.001 4.999z"></path></svg>
                    <span><?php _e('Watch tutorials', 'awp'); ?></span>
                </div> 
            </a>
            
           <a href="https://www.facebook.com/groups/wawpcommunity" target="_blank">
                <div class="help-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="help-icon"><path d="M16.604 11.048a5.67 5.67 0 0 0 .751-3.44c-.179-1.784-1.175-3.361-2.803-4.44l-1.105 1.666c1.119.742 1.8 1.799 1.918 2.974a3.693 3.693 0 0 1-1.072 2.986l-1.192 1.192 1.618.475C18.951 13.701 19 17.957 19 18h2c0-1.789-.956-5.285-4.396-6.952z"></path><path d="M9.5 12c2.206 0 4-1.794 4-4s-1.794-4-4-4-4 1.794-4 4 1.794 4 4 4zm0-6c1.103 0 2 .897 2 2s-.897 2-2 2-2-.897-2-2 .897-2 2-2zm1.5 7H8c-3.309 0-6 2.691-6 6v1h2v-1c0-2.206 1.794-4 4-4h3c2.206 0 4 1.794 4 4v1h2v-1c0-3.309-2.691-6-6-6z"></path></svg>
                    <span><?php _e('Join our community', 'awp'); ?></span>
                                     
                </div> 
            </a>


           <a href="https://api.whatsapp.com/send?phone=447441429009&text=Plugin-help" target="_blank">
                <div class="help-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="help-icon"><path d="M5 18v3.766l1.515-.909L11.277 18H16c1.103 0 2-.897 2-2V8c0-1.103-.897-2-2-2H4c-1.103 0-2 .897-2 2v8c0 1.103.897 2 2 2h1zM4 8h12v8h-5.277L7 18.234V16H4V8z"></path><path d="M20 2H8c-1.103 0-2 .897-2 2h12c1.103 0 2 .897 2 2v8c1.103 0 2-.897 2-2V4c0-1.103-.897-2-2-2z"></path></svg>
                    <span><?php _e('Contact us', 'awp'); ?></span>   
                </div> 
            </a>


          </div>
		
		
		
            </div>
        </div>
        </div>
    </div>
     </div>
</div>
