<?php

function get_country_name($country_code) {
    $countries = include WWO_PATH . 'admin/country-code.php';
    $result = [];
    foreach($countries as $country){
        $result[$country['phone']] = $country['name'];
    }
    return $result[$country_code];
}

function create_awp_instance() {
    $settings = get_option('wwo_settings');
    $token = $settings['general']['access_token'];
    $instance_id = wp_remote_post('https://app.wawp.net/api/createinstance?access_token'.$token);
    return $instance_id;
}

function get_awp_qrcode() {
    $settings = get_option('wwo_settings');
    $token = $settings['general']['access_token'];
    $instance_id = $settings['general']['instance_id'];
    $qr = wp_remote_post('https://app.wawp.net/api/createinstance?access_token='.$token);
    return $qr;
}

function awp_break_number($ountry, $to) {
    if(substr($to,0,1)=="0"){
        $fix = substr($to,1,strlen($to));
    }elseif(!in_array(substr($to,0,1), ["0", "+"])){
        $fix = $to;
    }elseif(substr($to,0,strlen($country))==$country){
        $fix = substr($to,strlen($country),strlen($to));
    }
    return $fix;
}

