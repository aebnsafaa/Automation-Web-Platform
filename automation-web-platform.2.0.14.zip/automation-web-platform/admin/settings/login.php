 <a href="https://wawp.net/docs/third-party/wordpress-woocommerce/otp-login-settings/" target="_blank"><div class="info-banner setting-card login-card d-none">
  		        <label for="awp_banner_info" class="banner-title"><?php _e('OTP Login', 'awp'); ?></label>
  		        <p class="banner-text"><?php _e('You can set up the Send WhatsApp login message button and customize the login message...', 'awp'); ?></p>
  		    </div></a>


<div class="otp-card setting-card login-card d-none">
    <div class="heading-bar credential">
        <div class="access-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="title-icon"><path d="M13.9093 12.3603L17.0007 20.8537L14.1816 21.8798L11.0902 13.3864L6.91797 16.5422L8.4087 1.63318L19.134 12.0959L13.9093 12.3603Z"></path></svg>
            <span><?php esc_html_e( 'OTP Button', 'awp' ); ?></span>
        </div>
    </div>
    <div class="fields">
        <div class="field">
            <label for="login_otp_btn_text" class="fw-bold"><?php esc_html_e( 'Send OTP Button Text', 'awp' ); ?></label>
            <input type="text" name="login[otp_btn_text]" id="login_otp_btn_text" class="regular-text" placeholder="" value="<?= $settings['login']['otp_btn_text'] ?? 'Send OTP' ?>" required>
        </div>
        <div class="field">
            <label for="login_btn_text" class="fw-bold"><?php esc_html_e( 'Login Button Text', 'awp' ); ?></label>
            <input type="text" name="login[login_btn_text]" id="login_btn_text" class="regular-text" placeholder="" value="<?= $settings['login']['login_btn_text'] ?? 'Login' ?>" required>
        </div>
    </div>
</div>
<div class="otp-card setting-card login-card d-none">
    <div class="heading-bar credential">
        <div class="access-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="title-icon"><path d="M7.29117 20.8242L2 22L3.17581 16.7088C2.42544 15.3056 2 13.7025 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C10.2975 22 8.6944 21.5746 7.29117 20.8242ZM7 12C7 14.7614 9.23858 17 12 17C14.7614 17 17 14.7614 17 12H15C15 13.6569 13.6569 15 12 15C10.3431 15 9 13.6569 9 12H7Z"></path></svg>
            <span><?php esc_html_e( 'Message', 'awp' ); ?></span>
        </div>
    </div>
    <div class="field">
        <label for="login_message" class="fw-bold"><?php esc_html_e( 'Message Template for member', 'awp' ); ?></label>
        <textarea rows="5" type="text" name="login[message]" id="login_message" class="regular-text" placeholder="Write your message template" required><?= $settings['login']['message'] ?? 'Hi {{name}},

{{otp}} is your Login Generated OTP code.

Do not share this code with others.' ?></textarea>
        <p class="mb-0 text-small text-muted">
             <?php esc_html_e( 'Text Shortcode', 'awp' ); ?> <br>
            <code>{{name}}</code> <?php esc_html_e( 'Member name', 'awp' ); ?> <br>
            <code>{{otp}}</code> <?php esc_html_e( 'Generated OTP code', 'awp' ); ?>
        </p>
    </div>
</div>
<div class="otp-card setting-card login-card d-none">
    <div class="heading-bar credential">
        <div class="access-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="title-icon"><path d="M12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22ZM11.0026 16L18.0737 8.92893L16.6595 7.51472L11.0026 13.1716L8.17421 10.3431L6.75999 11.7574L11.0026 16Z"></path></svg>
            <span><?php esc_html_e( 'Success', 'awp' ); ?></span>
        </div>
    </div>
    <div class="field">
        <label for="login_url_redirection" class="fw-bold">URL Redirection</label>
        <input type="text" name="login[url_redirection]" id="login_url_redirection" class="regular-text" placeholder="https://" value="<?= $settings['login']['url_redirection'] ?? '' ?>">
        <p class="mb-0 text-small text-muted"><?php esc_html_e( 'If empty, user will be get in my-account dashboard', 'awp' ); ?></p>
    </div>
</div>
<?php
$login_error_1 = 'Something wrong with your login';
$login_error_2 = 'Missmatch passkey. Try again.';
$login_error_3 = 'Failed to send passkey. Please try again or contact administrator.';
$login_error_4 = 'Request sent! Check your WhatsApp.';
$login_error_5 = 'This number is not registered on this site. Please try again with a valid number, login with email or register now.';
$login_error_6 = 'WhatsApp number is not provided.';
?>
<div class="otp-card setting-card login-card d-none">
    <div class="heading-bar credential">
        <div class="access-title">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" class="title-icon"><path d="M12.8659 3.00017L22.3922 19.5002C22.6684 19.9785 22.5045 20.5901 22.0262 20.8662C21.8742 20.954 21.7017 21.0002 21.5262 21.0002H2.47363C1.92135 21.0002 1.47363 20.5525 1.47363 20.0002C1.47363 19.8246 1.51984 19.6522 1.60761 19.5002L11.1339 3.00017C11.41 2.52187 12.0216 2.358 12.4999 2.63414C12.6519 2.72191 12.7782 2.84815 12.8659 3.00017ZM10.9999 16.0002V18.0002H12.9999V16.0002H10.9999ZM10.9999 9.00017V14.0002H12.9999V9.00017H10.9999Z"></path></svg>
            <span><?php esc_html_e( 'Error Responses', 'awp' ); ?></span>
        </div>
    </div>
    <div class="fields">
        <div class="field">
            <input type="text" name="login[error_1]" id="login_error_1" class="regular-text" placeholder="<?= $login_error_1 ?>" value="<?= $settings['login']['error_1'] ?? $login_error_1 ?>" required>
            <p class="mb-0 text-small text-muted"><?= $login_error_1 ?></p>
        </div>
        <div class="field">
            <input type="text" name="login[error_2]" id="login_error_2" class="regular-text" placeholder="<?php $login_error_2 ?>" value="<?= $settings['login']['error_2'] ?? $login_error_2 ?>" required>
            <p class="mb-0 text-small text-muted"><?= $login_error_2 ?></p>
        </div>
        <div class="field">
            <input type="text" name="login[error_3]" id="login_error_3" class="regular-text" placeholder="<?php $login_error_3 ?>" value="<?= $settings['login']['error_3'] ?? $login_error_3 ?>" required>
            <p class="mb-0 text-small text-muted"><?= $login_error_3 ?></p>
        </div>
        <div class="field">
            <input type="text" name="login[error_4]" id="login_error_4" class="regular-text" placeholder="<?php $login_error_4 ?>" value="<?= $settings['login']['error_4'] ?? $login_error_4 ?>" required>
            <p class="mb-0 text-small text-muted"><?= $login_error_4 ?></p>
        </div>
        <div class="field">
            <input type="text" name="login[error_5]" id="login_error_5" class="regular-text" placeholder="<?php $login_error_5 ?>" value="<?= $settings['login']['error_5'] ?? $login_error_5 ?>" required>
            <p class="mb-0 text-small text-muted"><?= $login_error_5 ?></p>
        </div>
        <div class="field">
            <input type="text" name="login[error_6]" id="login_error_6" class="regular-text" placeholder="<?php $login_error_6 ?>" value="<?= $settings['login']['error_6'] ?? $login_error_6 ?>" required>
            <p class="mb-0 text-small text-muted"><?= $login_error_6 ?></p>
        </div>
    </div>
</div>

