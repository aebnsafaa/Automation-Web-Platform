jQuery(function($) {
    if ($(".whatsapp-number input") && $(".whatsapp-number input").length ) {
        $(".whatsapp-number input").on("keypress keyup blur",function (event) {    
        	$(this).val($(this).val().replace(/[^\d].+/, ""));
        	if ((event.which < 48 || event.which > 57)) {
        		event.preventDefault();
        	}
        });
        var iti = window.intlTelInput(document.querySelector(".whatsapp-number input"), {
          initialCountry: "auto",
          geoIpLookup: function(callback) {
            if (typeof wc_get_customer_ip_address === 'function') {
              wc_get_customer_ip_address(function(ipAddress) {
                if (ipAddress) {
                  $.get('https://ipapi.co/' + ipAddress + '/country/', function(response) {
                    callback(response.toLowerCase());
                  });
                } else {
                  callback('');
                }
              });
            } else {
              callback('');
            }
          },
          utilsScript: "<?php echo plugins_url( 'assets/js/utils.js', __FILE__ ); ?>",
        });
        window.iti = iti;
        $('.whatsapp-number input').on('blur', function () {
            $(this).val(iti.getNumber().replace('+',''));
        });
        $('.intl-tel-input').css('display', 'block');
    }
});
