jQuery(function($) {
    var phoneField = $("#billing_phone").length ? $("#billing_phone") : $("#billing-phone");
    if (phoneField.length) {
        var iti = window.intlTelInput(phoneField[0], {
            initialCountry: "auto",
            geoIpLookup: function(success, failure) {
                $.getJSON("https://ipapi.co/jsonp/?callback=?")
                .done(function(resp) {
                	console.log(resp);
                    success(resp.country_calling_code);
                })
                .fail(function() {
                    failure();
                });
            },
            utilsScript: "<?php echo esc_url( plugins_url( 'assets/js/utils.js', __FILE__ ) ); ?>"
        });

        window.iti = iti;		
        iti.promise.then(function() {
            phoneField.val(iti.getNumber().replace('+',''));
        });		
        phoneField.on('blur', function() {
            $(this).val(iti.getNumber().replace('+',''));
        });

        $('.intl-tel-input').css('display', 'block');

        $(document).on('change', '#billing_country', function() {
            iti.setCountry(this.value);
        });

        var initialCountry = $('#billing_country').val() || 'us';
        iti.setCountry(initialCountry);
    }
});