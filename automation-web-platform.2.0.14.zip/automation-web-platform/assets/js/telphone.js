// Initialize intl-tel-input for the login form
    document.addEventListener('DOMContentLoaded', function () {
        var input = document.querySelector("#login_your_whatsapp");
        var iti = window.intlTelInput(input, {
            initialCountry: "auto",
            geoIpLookup: function(callback) {
                jQuery.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
                    var countryCode = (resp && resp.country) ? resp.country : "";
                    callback(countryCode);
                });
            },
            utilsScript: "<?php echo esc_url( plugins_url( 'assets/js/utils.js', __FILE__ ) ); ?>" // Use utils script for formatting/validation
        });

        // Remove country code or 00 prefix when the input changes
        input.addEventListener('change', function() {
            var phoneNumber = iti.getNumber().replace(/^(\+00|\+)/, '');
            // Update the input value with the formatted number
            input.value = phoneNumber;
        });
    });
    
    
    
    // Initialize intl-tel-input
    document.addEventListener('DOMContentLoaded', function () {
        var input = document.querySelector("#register_your_whatsapp");
        var iti = window.intlTelInput(input, {
            initialCountry: "auto",
            geoIpLookup: function(callback) {
                jQuery.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
                    var countryCode = (resp && resp.country) ? resp.country : "";
                    callback(countryCode);
                });
            },
            utilsScript: "<?php echo esc_url( plugins_url( 'assets/js/utils.js', __FILE__ ) ); ?>" // Use utils script for formatting/validation
        });

        // Remove country code or 00 prefix when the input changes
        input.addEventListener('change', function() {
            var phoneNumber = iti.getNumber().replace(/^(\+00|\+)/, '');
            // Update the input value with the formatted number
            input.value = phoneNumber;
        });
    });