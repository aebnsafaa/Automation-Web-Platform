<div>
    <h3><?php _e( 'WhatsApp Notification', 'nano-wb' ); ?></h3>
    <fieldset>
        <legend><?php _e('Send WhatsApp message to specific number after submit form<br>These are following tags you can use:', 'nano-wb'); ?><br><?php $cf7_options['form']->suggest_mail_tags(); ?></legend>
        <table class="form-table">
            <tbody>
            <tr>
                <th scope="row"><label for="wpcf7-wa-sender"><?php _e( 'To:', 'nano-wb' ); ?></label></th>
                <td>
                    <input type="text" value="<?php echo $cf7_options['phone']; ?>" size="70" class="large-text code" name="wpcf7-wa[phone]" id="wpcf7-wa-sender">
                    <p class="description"><?php _e( 'Add country code without (+) sign before number', 'nano-wb' ); ?></p>
                </td>
            </tr>

            <tr>
                <th scope="row"><label for="wpcf7-wa-message"><?php _e( 'Message:', 'nano-wb' ); ?></label></th>
                <td>
                    <textarea class="large-text" rows="4" cols="100" name="wpcf7-wa[message]" id="wpcf7-wa-message"><?php echo $cf7_options['message']; ?></textarea>
                </td>
            </tr>
            
            <tr>
                <th scope="row"><label for="wpcf7-wa-image"><?php _e( 'Image Attachment:', 'nano-wb' ); ?></label></th>
                <td>
                    <input type="text" value="<?php echo $cf7_options['image']; ?>" size="70" class="large-text code" name="wpcf7-wa[image]" id="wpcf7-wa-image">
                    <p class="description"><?php _e( 'Insert image url to attach into message (Max 1 MB)', 'nano-wb' ); ?></p>
                </td>
            </tr>
        </tbody></table>
    </fieldset>
</div>