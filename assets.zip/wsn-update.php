<?php
if ( !isset( $_POST['action'] ) ) {
	echo '0';
	exit;
}

add_action( 'admin_init', 'wawp_plugin_update_check' );

function wawp_plugin_update_check() {
    $connection = json_decode( get_option( 'wnt_connection' ), true );
    $obj = new stdClass();
    $obj->slug = 'Wawp/wawp.php';
    $obj->name = 'wawp';
    $obj->plugin_name = 'wawp.php';
    $obj->new_version = substr( $connection['data']['downloadable']['name'], 1 );
    $obj->url = 'https://wawp.net';
    $obj->package = $connection['data']['downloadable']['url'];

    switch ( $_POST['action'] ) {
        case 'version':
            echo serialize( $obj );
            break;
        case 'info':
            $obj->requires = '4.7';
            $obj->tested = '5.2';
            $obj->downloaded = 10000;
            $obj->last_updated = '2023-03-12';
            $obj->sections = array(
                'description' => 'WhatsApp Order Notification for WooCommerce',
                'changelog' => 'View wawp site (https://wawp.net) for changelogs'
            );
            $obj->download_link = $obj->package;
            echo serialize( $obj );
            break;
        case 'license':
            echo serialize( $obj );
            break;
    }
    exit;
}
?>
