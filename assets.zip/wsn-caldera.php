<div class="caldera-config-group">
	<label>WhatsApp Number</label>
	<div class="caldera-config-field">		
		<input type="text" id="{{_id}}_number" class="block-input magic-tag-enabled field-config" name="{{_name}}[number]" value="{{number}}" >
	</div>
</div>
<div class="caldera-config-group">
	<label>Message</label>
	<div class="caldera-config-field">		
		<textarea id="{{_id}}_message" class="block-input required magic-tag-enabled field-config" name="{{_name}}[message]" required>{{message}}</textarea>
	</div>
</div>
<div class="caldera-config-group">
	<label>Image Attachment (Max 1 MB)</label>
	<div class="caldera-config-field">		
		<input type="text" id="{{_id}}_img" class="block-input magic-tag-enabled field-config" name="{{_name}}[img]" value="{{img}}" >
	</div>
</div>