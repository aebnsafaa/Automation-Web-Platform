=== Automation Web Platform ===
Contributors: 101Gen
Tags: whatsapp, woocoomerce,Send notices, notification messages, abandoned cart,
Requires at least: 3.0.1
Tested up to: 6.1.1
Requires PHP: 7.0
Stable tag: 1.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Notify your customers about orders and abandoned carts via "WhatsApp" or "WhatsApp Business", for woocommerce system

== Description ==

<p>Notify your customers about orders and abandoned carts via "WhatsApp" or "WhatsApp Business", for woocommerce wordpress system, and send notifications such as registering a new order, or knowing the status of an existing order</p>


<h3>Why do you need this feature?</h3>

<strong>
Your customers usually face the habit of forgetting your site, which leads to losing the customers you gained, because there are two types of customers
Type that does not care about e-mail and type that has overcrowded mail, so you are guaranteed to reach it in the right place </strong>


<h3>How does this feature affect your sales?</h3>

<strong>You give your customer a sense of interest and follow-up, which makes him more reassured about your service, and therefore he may buy from you again.<strong>


<h3>About WAWP.net Automation Web Platform</h3>
<strong>You can automatically send all of the following types of messages to customers using their registered WhatsApp numbers</strong> 
<ul>
	<li>The possibility of direct linking and managing notifications from the WordPress panel</li>
	<li>Integrate with WooCommerce</li>
	<li>Integrate with Easy Digital Download</li>
	<li>Abandoned cart, and automatic follow-up of the customer</li>
	<li>Admin Notification (On-Hold)</li>
	<li>Order - New (Thankyou Page)</li>
	<li>Order - On Hold</li>
	<li>Order - Processing</li>
	<li>Order - Completed</li>
	<li>Order - Pending</li>
	<li>Order - Failed</li>
	<li>Order - Refunded</li>
	<li>Order - Cancelled</li>
	<li>Order - Notes</li>
	<li>Order - Draft</li>
	<li>Abandoned cart messages</li>
	<li>Follow Up On-Hold Order #1</li>
	<li>Follow Up On-Hold Order #2</li>
	<li>Follow Up On-Hold Order #3</li>
	<li>Follow Up On-Hold Order After "Time per Hours"</li>
	<li>Follow Up Completed Order After"Time per Hours"</li>
	<li>Easy Digital Downloads - New Order Notification</li>
	<li>Easy Digital Downloads - Complete Order Notification</li>

</ul>



<h3>How do you use the plugin?</h3>
<strong>You need an account on https://app.wawp.net/signup, Free signup to get 150 messages per month, automatically renewed</strong> 
<p>You will also get the Instance ID credentials, and the access token of your account for the authentication and sending process</p>

<p>For more information about setting up the plugin on your site, please see the</p>

<p>Help Center https://wawp.net/docs</p>


<ul>
	<li>Send notifications directly</li>
	<li>Create an auto reply</li>
	<li>Access to the API</li>
	<li>Create a chat bot</li>
	<li>Access to the cloud file manager</li>
	<li>Access to the support center</li>
	<li>Send private messages</li>
	<li>Send group messages</li>
	<li>Send customized messages according to the status of Woocommerce request</li>
	<li>You can get a free account with up to 150 messages per month</li>
	<li>You can upgrade to higher packages at any time</li>
</ul>


<h3>Paid features</h3>
<strong>You can increase your sending limit, packages starting from 10,000 messages per month</strong> 
<p>Use the discount code, to get a 75% discount for your early access to the plugin on the wordpress store
Use code "HiWordpress"</p>



== Screenshots ==
1. Notification-Message
2. Follow-Up-Message
3. Other-Integration
4. Help



== Changelog ==
= 1.1.1 =
Release