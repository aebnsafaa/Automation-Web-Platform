jQuery(function($) {
    if ($("#edd-phone") && $("#edd-phone").length ) {
        $("#edd-phone").on("keypress keyup blur",function (event) {    
        	$(this).val($(this).val().replace(/[^\d].+/, ""));
        	if ((event.which < 48 || event.which > 57)) {
        		event.preventDefault();
        	}
        });
        var iti = window.intlTelInput(document.querySelector("#edd-phone"), {
          initialCountry: "auto",
          geoIpLookup: function(callback) {
            $.getJSON('https://freegeoip.app/json/', function(resp) {
              var countryCode = (resp && resp.country_code) ? resp.country_code : "";
              callback(countryCode);
            });
          },
          utilsScript: "<?php echo plugins_url( 'assets/js/utils.js', __FILE__ ); ?>",
        });
        window.iti = iti;
        $('#edd-phone').on('blur', function () {
            $(this).val(iti.getNumber().replace('+',''));
        });
        $('.intl-tel-input').css('display', 'block');
    }
});
