jQuery(function($) {
    if ($("#billing_phone") && $("#billing_phone").length ) {
        var iti = window.intlTelInput(document.querySelector("#billing_phone"), {
          initialCountry: "auto",
          geoIpLookup: function(success, failure) {
            $.getJSON("https://ipapi.co/json/")
              .done(function(resp) {
                success(resp.country_calling_code);
              })
              .fail(function() {
                failure();
              });
          },
          utilsScript: "assets/js/utils.js",
        });
        window.iti = iti;		
		iti.promise.then(function() {
			$('#billing_phone').val(iti.getNumber().replace('+',''));
		});		
        $('#billing_phone').on('blur', function () {
            $(this).val(iti.getNumber().replace('+',''));
        });
        $('.intl-tel-input').css('display', 'block');
		$(document).on('change', '#billing_country', function(e) {
			iti.setCountry(this.value);
		});
		iti.setCountry($('#billing_country').val());						
    }
});
