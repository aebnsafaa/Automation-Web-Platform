<?php
class wsn_ui {

	public function __construct() {
		$this->notif  = get_option( 'wsn_notifications' );
		$this->instances  = get_option( 'wsn_instances' );
	}

    public function is_plugin_active( $plugin ) {
        return in_array( $plugin, (array) get_option( 'active_plugins', array() ) );
    }
    
	public function admin_page() {
		?>
        <div class="wrap" id="wsn-wrap">
            <h1>
				<?php echo get_admin_page_title(); ?>
            </h1>
            <div class="form-wrapper">
				<div class="wsn-tab-wrapper">
					<ul class="nav-tab-wrapper woo-nav-tab-wrapper">
					<li name="wsn_notifications[notification-message]" class="nav-tab nav-tab-active"><a href="#notification"><?php _e('Notification Message', 'wawp'); ?></a></li>
<li class="nav-tab"><a href="#followup"><?php _e('Follow-Up Message', 'wawp'); ?></a></li>
<li class="nav-tab"><a href="#other"><?php _e('Other Integration', 'wawp'); ?></a></li>
<li class="nav-tab"><a href="#help">
	
<?php _e('Help', 'wawp'); ?></a></li>

					</ul>
                    <form method="post" action="options.php">
    					<div class="wp-tab-panels" id="notification">
    							<?php
    								$this->notification_settings();	
    							?>
    					</div>
    					<div class="wp-tab-panels" id="followup" style="display: none;">
    							<?php
    								$this->followup_settings();	
    							?>
    					</div>
        				<div class="wp-tab-panels" id="other" style="display: none;">
    							<?php
    								$this->other_settings();	
    							?>
    					</div>
    	            </form>
					<div class="wp-tab-panels" id="help" style="display: none;">
							<?php
    								$this->help_info();	
							?>
					</div>
				</div>				
				<div class="info">
							<?php
								$this->setup_info();	
							?>					
				</div>
			</div>
        </div>
		<?php
	}	

	public function notification_settings() {
	    if( $this->is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
    		$status_list = wc_get_order_statuses();
    		$status_list_temp = array();
    		$original_status = array( 
    			'pending',
    			'failed',
    			'on-hold',
    			'processing',
    			'completed',
    			'refunded',
    			'cancelled',
    		);
    		foreach( $status_list as $key => $status ) {
    			$status_name = str_replace( "wc-", "", $key );
    			if ( !in_array( $status_name, $original_status ) ) {
    				$status_list_temp[$status] = $status_name;
    			}
    		}
    		$status_list = $status_list_temp;	    
	    }
		?>
			<?php settings_fields( 'wsn_storage_notifications' ); ?>
			<table class="form-table wsn-table">
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[default_country]">
					<?php _e('Default Country Code:', 'wawp'); ?>
				  </label>
				</th>
				<td>
					<input type="text" name="wsn_notifications[default_country]" placeholder="Your country code" class="regular-text" value="<?php echo stripcslashes(isset($this->notif['default_country']) ? $this->notif['default_country'] : ''); ?>">
				    <p><em><?php _e('Insert country code only if your customer from a single country. This also will remove country detection library on checkout page. Leave blank if your customer from many countries.', 'wawp'); ?></em></p>
			    </td>
			  </tr>				
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[admin_onhold]">
					<?php _e('Admin Notification (On-Hold):', 'wawp'); ?>
				  </label>
				</th>
				<td>
					<p class="wsn-admin-number">
						<input type="text" name="wsn_notifications[admin_onhold_number]" placeholder="Admin Number with country code" class="admin_number regular-text admin_number" value="<?php echo stripcslashes(isset($this->notif['admin_onhold_number']) ? $this->notif['admin_onhold_number'] : ''); ?>">
					</p>	
				    <textarea class="wsn-emoji" id="wsn_notifications[admin_onhold]" name="wsn_notifications[admin_onhold]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['admin_onhold']) ? $this->notif['admin_onhold'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="admin_onhold_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[admin_onhold_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text admin_onhold_img" value="<?php echo stripcslashes(isset($this->notif['admin_onhold_img']) ? $this->notif['admin_onhold_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>
			    </td>
			  </tr>								
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[customer_neworder]">
					<?php _e('Order - New (Thankyou Page):', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[customer_neworder]" name="wsn_notifications[customer_neworder]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['customer_neworder']) ? $this->notif['customer_neworder'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="customer_neworder_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[customer_neworder_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text customer_neworder_img" value="<?php echo stripcslashes(isset($this->notif['customer_neworder_img']) ? $this->notif['customer_neworder_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_onhold]">
					<?php _e('Order - On Hold:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_onhold]" name="wsn_notifications[order_onhold]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_onhold']) ? $this->notif['order_onhold'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_onhold_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_onhold_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_onhold_img" value="<?php echo stripcslashes(isset($this->notif['order_onhold_img']) ? $this->notif['order_onhold_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>				
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_processing]">
					<?php _e('Order - Processing:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_processing]" name="wsn_notifications[order_processing]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_processing']) ? $this->notif['order_processing'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_processing_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_processing_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_processing_img" value="<?php echo stripcslashes(isset($this->notif['order_processing_img']) ? $this->notif['order_processing_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_completed]">
					<?php _e('Order - Completed:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_completed]" name="wsn_notifications[order_completed]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_completed']) ? $this->notif['order_completed'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_completed_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_completed_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_completed_img" value="<?php echo stripcslashes(isset($this->notif['order_completed_img']) ? $this->notif['order_completed_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_pending]">
					<?php _e('Order - Pending:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_pending]" name="wsn_notifications[order_pending]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_pending']) ? $this->notif['order_pending'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_pending_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_pending_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_pending_img" value="<?php echo stripcslashes(isset($this->notif['order_pending_img']) ? $this->notif['order_pending_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_failed]">
					<?php _e('Order - Failed:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_failed]" name="wsn_notifications[order_failed]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_failed']) ? $this->notif['order_failed'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_failed_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_failed_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_failed_img" value="<?php echo stripcslashes(isset($this->notif['order_failed_img']) ? $this->notif['order_failed_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_refunded]">
					<?php _e('Order - Refunded:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_refunded]" name="wsn_notifications[order_refunded]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_refunded']) ? $this->notif['order_refunded'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_refunded_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_refunded_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_refunded_img" value="<?php echo stripcslashes(isset($this->notif['order_refunded_img']) ? $this->notif['order_refunded_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_cancelled]">
					<?php _e('Order - Cancelled:', 'wawp'); ?>
				  </label>
				</th>
				<td>
				    <textarea class="wsn-emoji" id="wsn_notifications[order_cancelled]" name="wsn_notifications[order_cancelled]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_cancelled']) ? $this->notif['order_cancelled'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_cancelled_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_cancelled_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_cancelled_img" value="<?php echo stripcslashes(isset($this->notif['order_cancelled_img']) ? $this->notif['order_cancelled_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			    </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[order_note]">
					<?php _e('Order - Notes:', 'wawp'); ?>
				  </label>
				</th>
				<td><textarea class="wsn-emoji" id="wsn_notifications[order_note]" name="wsn_notifications[order_note]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_note']) ? $this->notif['order_note'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_note_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_note_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_note_img" value="<?php echo stripcslashes(isset($this->notif['order_note_img']) ? $this->notif['order_note_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>
				</td>
			  </tr>
			<?php if ( !empty( $status_list ) ) : ?>
			<?php foreach ( $status_list as $status_name => $custom_status ) : ?>
			<tr valign="top">
				<th scope="row">
					<label for="wsn_notifications[order_<?php echo $custom_status; ?>]">
						<?php echo sprintf( __( 'Order - %s:', 'wawp' ), $status_name ); ?>
					</label>
				</th>
				<td><textarea class="wsn-emoji" id="wsn_notifications[order_<?php echo $custom_status; ?>]" name="wsn_notifications[order_<?php echo $custom_status; ?>]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['order_'.$custom_status]) ? $this->notif['order_'.$custom_status] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="order_<?php echo $custom_status; ?>_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[order_<?php echo $custom_status; ?>_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text order_<?php echo $custom_status; ?>_img" value="<?php echo stripcslashes(isset($this->notif['order_'.$custom_status.'_img']) ? $this->notif['order_'.$custom_status.'_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>					
				</td>
			</tr>
			<?php endforeach; ?>
			<?php endif; ?>			  
			</table>    	
			<footer class="wsn-panel-footer">
                <input type="submit" class="button-primary"
                       value="<?php _e( 'Save Changes', 'wawp' ); ?>">
            </footer>
		<?php
	}

	public function followup_settings() {
		?>
			<?php settings_fields( 'wsn_storage_notifications' ); ?>
			  <!-- wsn -->
			  
            <div class="tabs">
                
              <input type="radio" name="tabs" id="tabone" checked="checked">
              <label for="tabone"><?php _e('Follow Up On-Hold Order #1:', 'wawp'); ?> </label>
              <div class="tab">
    			<table class="form-table wsn-table">
    			  <tr valign="top">
    				<th scope="row"> <label for="wsn_notifications[followup_onhold]">
    					<?php _e('Follow Up On-Hold Order #1:', 'wawp'); ?>
    				  </label>
    				</th>
    				  <td>
    				      <textarea class="wsn-emoji" id="wsn_notifications[followup_onhold]" name="wsn_notifications[followup_onhold]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['followup_onhold']) ? $this->notif['followup_onhold'] : ''); ?></textarea>
    				    <p class="wsn-upload-img">
                            <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="followup_onhold_img" value="Upload Image">
        				    <input type="text" name="wsn_notifications[followup_onhold_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text followup_onhold_img" value="<?php echo stripcslashes(isset($this->notif['followup_onhold_img']) ? $this->notif['followup_onhold_img'] : ''); ?>">
                        </p>
    				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
    			      </td>
    			  </tr>
    			  <tr valign="top" style="border-bottom: 1px solid #ccc;">
    				<th scope="row"> <label for="wsn_notifications[followup_onhold_day]">
    					<?php _e('Follow Up On-Hold Order After:', 'wawp'); ?>
    				  </label>
    				</th>
    				<td><input id="wsn_notifications[followup_onhold_day]" name="wsn_notifications[followup_onhold_day]" type="number" cols="50" rows="5" placeholder="24" value="<?php echo stripcslashes(isset($this->notif['followup_onhold_day']) ? $this->notif['followup_onhold_day'] : ''); ?>"> Hour(s)</td>
    			  </tr>	
 			    </table>
              </div>			  
              
              <input type="radio" name="tabs" id="tabtwo">
              <label for="tabtwo"><?php _e('Follow Up On-Hold Order #2:', 'wawp'); ?></label>
              <div class="tab">
    			<table class="form-table wsn-table">
    			  <tr valign="top">
    				<th scope="row"> <label for="wsn_notifications[followup_onhold_2]">
    					<?php _e('Follow Up On-Hold Order #2:', 'wawp'); ?>
    				  </label>
    				</th>
    				  <td>
    				      <textarea class="wsn-emoji" id="wsn_notifications[followup_onhold_2]" name="wsn_notifications[followup_onhold_2]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['followup_onhold_2']) ? $this->notif['followup_onhold_2'] : ''); ?></textarea>
    				    <p class="wsn-upload-img">
                            <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="followup_onhold_img_2" value="Upload Image">
        				    <input type="text" name="wsn_notifications[followup_onhold_img_2]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text followup_onhold_img_2" value="<?php echo stripcslashes(isset($this->notif['followup_onhold_img_2']) ? $this->notif['followup_onhold_img_2'] : ''); ?>">
                        </p>
    				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
    			      </td>
    			  </tr>
    			  <tr valign="top" style="border-bottom: 1px solid #ccc;">
    				<th scope="row"> <label for="wsn_notifications[followup_onhold_day_2]">
    					<?php _e('Follow Up On-Hold Order #2 After:', 'wawp'); ?>
    				  </label>
    				</th>
    				<td><input id="wsn_notifications[followup_onhold_day_2]" name="wsn_notifications[followup_onhold_day_2]" type="number" cols="50" rows="5" placeholder="48" value="<?php echo stripcslashes(isset($this->notif['followup_onhold_day_2']) ? $this->notif['followup_onhold_day_2'] : ''); ?>"> Hour(s)</td>
    			  </tr>	
 			    </table>
              </div>			  
            
              <input type="radio" name="tabs" id="tabthree">
              <label for="tabthree"><?php _e('Follow Up On-Hold Order #3:', 'wawp'); ?></label>
              <div class="tab">
    			<table class="form-table wsn-table">
    			  <tr valign="top">
    				<th scope="row"> <label for="wsn_notifications[followup_onhold_3]">
    					<?php _e('Follow Up On-Hold Order #3:', 'wawp'); ?>
    				  </label>
    				</th>
    				  <td>
    				      <textarea class="wsn-emoji" id="wsn_notifications[followup_onhold_3]" name="wsn_notifications[followup_onhold_3]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['followup_onhold_3']) ? $this->notif['followup_onhold_3'] : ''); ?></textarea>
    				    <p class="wsn-upload-img">
                            <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="followup_onhold_img_3" value="Upload Image">
        				    <input type="text" name="wsn_notifications[followup_onhold_img_3]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text followup_onhold_img_3" value="<?php echo stripcslashes(isset($this->notif['followup_onhold_img_3']) ? $this->notif['followup_onhold_img_3'] : ''); ?>">
                        </p>
    				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
    			      </td>
    			  </tr>
    			  <tr valign="top" style="border-bottom: 1px solid #ccc;">
    				<th scope="row"> <label for="wsn_notifications[followup_onhold_day_3]">
    					<?php _e('Follow Up On-Hold Order #3 After:', 'wawp'); ?>
    				  </label>
    				</th>
    				<td><input id="wsn_notifications[followup_onhold_day_3]" name="wsn_notifications[followup_onhold_day_3]" type="number" cols="50" rows="5" placeholder="72" value="<?php echo stripcslashes(isset($this->notif['followup_onhold_day_3']) ? $this->notif['followup_onhold_day_3'] : ''); ?>"> Hour(s)</td>
    			  </tr>	
 			    </table>
              </div>			  
              
            </div>  
            
			<table class="form-table wsn-table">
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[followup_aftersales]">
					<?php _e('Follow Up Completed Order:', 'wawp'); ?>
				  </label>
				</th>
				  <td>
				      <textarea class="wsn-emoji" id="wsn_notifications[followup_aftersales]" name="wsn_notifications[followup_aftersales]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['followup_aftersales']) ? $this->notif['followup_aftersales'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="followup_aftersales_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[followup_aftersales_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text followup_aftersales_img" value="<?php echo stripcslashes(isset($this->notif['followup_aftersales_img']) ? $this->notif['followup_aftersales_img'] : ''); ?>">
                    </p>
				    <p><em><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			      </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[followup_aftersales_day]">
					<?php _e('Follow Up Completed Order After:', 'wawp'); ?>
				  </label>
				</th>
				<td><input id="wsn_notifications[followup_aftersales_day]" name="wsn_notifications[followup_aftersales_day]" type="number" cols="50" rows="5" placeholder="72" value="<?php echo stripcslashes(isset($this->notif['followup_aftersales_day']) ? $this->notif['followup_aftersales_day'] : ''); ?>"> Hour(s)</td>
			  </tr>					
			  <tr valign="top" style="border-top: 1px solid #ccc;">
				  <th colspan="2">
					  <?php echo sprintf( __('Enable abandoned cart notification by installing "<a href="%s">Cartbounty Abandoned Carts</a>" plugin', 'wawp'), admin_url('plugin-install.php?s=Cartbounty%20Abandoned%20Cart&tab=search&type=term') ); ?>
				  </th>
			  </tr>					
			  <?php 
	            if( is_plugin_active( 'woo-save-abandoned-carts/cartbounty-abandoned-carts.php' ) ) {
			  ?>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[followup_abandoned]">
					<?php _e('Follow Up Abandoned Cart:', 'wawp'); ?>
				  </label>
				</th>
				  <td>
				      <textarea class="wsn-emoji" id="wsn_notifications[followup_abandoned]" name="wsn_notifications[followup_abandoned]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['followup_abandoned']) ? $this->notif['followup_abandoned'] : ''); ?></textarea>
				    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="followup_abandoned_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[followup_abandoned_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text followup_abandoned_img" value="<?php echo stripcslashes(isset($this->notif['followup_abandoned_img']) ? $this->notif['followup_abandoned_img'] : ''); ?>">
                    </p>
    			    <p><em><b><?php _e('Available tags:', 'wawp'); ?></b> %billing_first_name% %billing_last_name% %billing_email% %billing_phone% %product% %order_total% %currency%<br><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
			      </td>
			  </tr>
			  <tr valign="top">
				<th scope="row"> <label for="wsn_notifications[followup_abandoned_day]">
					<?php _e('Follow Up Abandoned Cart After:', 'wawp'); ?>
				  </label>
				</th>
				<td><input id="wsn_notifications[followup_abandoned_day]" name="wsn_notifications[followup_abandoned_day]" type="number" cols="50" rows="5" placeholder="24" value="<?php echo stripcslashes(isset($this->notif['followup_abandoned_day']) ? $this->notif['followup_abandoned_day'] : ''); ?>"> Hour(s)</td>
			  </tr>					
			<?php 
		        } 
		    ?>  
			</table>    	
			<footer class="wsn-panel-footer">
                <input type="submit" class="button-primary"
                       value="<?php _e( 'Save Changes', 'wawp' ); ?>">
            </footer>
		<?php
	}

	public function other_settings() {
		?>			
    		<?php settings_fields( 'wsn_storage_notifications' ); ?>
    		<table class="form-table wsn-table">
    		  <!-- wsn -->
    		  <tr valign="top">
    			<th scope="row">
    			    <label for="wsn_notifications[edd_notification]">
    				<?php _e('Easy Digital Downloads - New Order Notification:', 'wawp'); ?>
    			  </label>
    			</th>
    			  <td>
    			      <textarea class="wsn-emoji" id="wsn_notifications[edd_notification]" name="wsn_notifications[edd_notification]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['edd_notification']) ? $this->notif['edd_notification'] : ''); ?></textarea>
    			    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="edd_notification_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[edd_notification_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text edd_notification_img" value="<?php echo stripcslashes(isset($this->notif['edd_notification_img']) ? $this->notif['edd_notification_img'] : ''); ?>">
                    </p>
    			    <p><em><b><?php _e('Available tags:', 'wawp'); ?></b> %site_name% %product% %currency% %subtotal_price% %total_price% %payment_id% %payment_status% %payment_method% %date% %first_name% %last_name% %email%<br><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
    		      </td>
    		  </tr>
    		  <tr valign="top">
    			<th scope="row">
    			    <label for="wsn_notifications[edd_notification_complete]">
    				<?php _e('Easy Digital Downloads - Complete Order Notification:', 'wawp'); ?>
    			  </label>
    			</th>
    			  <td>
    			      <textarea class="wsn-emoji" id="wsn_notifications[edd_notification_complete]" name="wsn_notifications[edd_notification_complete]" cols="50" rows="5"><?php echo stripcslashes(isset($this->notif['edd_notification_complete']) ? $this->notif['edd_notification_complete'] : ''); ?></textarea>
    			    <p class="wsn-upload-img">
                        <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="edd_notification_complete_img" value="Upload Image">
    				    <input type="text" name="wsn_notifications[edd_notification_complete_img]" placeholder="Image URL (Max 1 MB)" class="image_url regular-text edd_notification_complete_img" value="<?php echo stripcslashes(isset($this->notif['edd_notification_complete_img']) ? $this->notif['edd_notification_complete_img'] : ''); ?>">
                    </p>
    			    <p><em><b><?php _e('Available tags:', 'wawp'); ?></b> %site_name% %product% %currency% %subtotal_price% %total_price% %payment_id% %payment_status% %payment_method% %date% %first_name% %last_name% %email%<br><?php _e('Leave blank to deactivate. Spintax format example: {hi|hello|hola}', 'wawp'); ?></em></p>				    
    		      </td>
    		  </tr>    		  
			</table>    	
			<footer class="wsn-panel-footer">
                <input type="submit" class="button-primary"
                       value="<?php _e( 'Save Changes', 'wawp' ); ?>">
            </footer>    		  
		<?php
	}	
	
	public function help_info() {
		?>
		<div class="wsn-panel">
			<div class="wsn-panel-body">
				<p style="margin-bottom: 10px;"><strong><?php _e( 'Below is list of available fields you can use on notification &amp; follow-up message:', 'wawp' ); ?></strong></p>
				<div class="wsn-item-body">
					<div class="wsn-body-left">					
						<strong><?php _e( 'ORDER', 'wawp' ); ?></strong><br />
						<strong><?php _e( 'Order ID:', 'wawp' ); ?></strong> %id%<br />
						<strong><?php _e( 'Order Key:', 'wawp' ); ?></strong> %order_key%<br />
						<strong><?php _e( 'Order Date:', 'wawp' ); ?></strong> %order_date%<br />
						<strong><?php _e( 'Order Summary Link:', 'wawp' ); ?></strong> %order_link%<br />
						
						<strong><?php _e( 'Product List:', 'wawp' ); ?></strong> %product%<br />
						<strong><?php _e( 'Product Name:', 'wawp' ); ?></strong> %product_name%<br />
						<strong><?php _e( 'Order Discount:', 'wawp' ); ?></strong> %order_discount%<br />
						<strong><?php _e( 'Cart Discount:', 'wawp' ); ?></strong> %cart_discount%<br />
						<strong><?php _e( 'Tax:', 'wawp' ); ?></strong> %order_tax%<br />
						<strong><?php _e( 'Currency Symbol:', 'wawp' ); ?></strong> %currency%<br />
						<strong><?php _e( 'Subtotal Amount:', 'wawp' ); ?></strong> %order_subtotal%<br />
						<strong><?php _e( 'Total Amount:', 'wawp' ); ?></strong> %order_total%<br />
						<strong><?php _e( 'Unique Transfer Code:', 'wawp' ); ?></strong> %unique_transfer_code%<br />
						<br />
						<strong><?php _e( 'BILLING DETAILS', 'wawp' ); ?></strong><br />
						<strong><?php _e( 'First Name:', 'wawp' ); ?></strong> %billing_first_name%<br />
						<strong><?php _e( 'Last Name:', 'wawp' ); ?></strong> %billing_last_name%<br />
						<strong><?php _e( 'Company:', 'wawp' ); ?></strong> %billing_company%<br />
						<strong><?php _e( 'Address 1:', 'wawp' ); ?></strong> %billing_address_1%<br />
						<strong><?php _e( 'Address 2:', 'wawp' ); ?></strong> %billing_address_2%<br />
						<strong><?php _e( 'City:', 'wawp' ); ?></strong> %billing_city%<br />
						<strong><?php _e( 'Postcode:', 'wawp' ); ?></strong> %billing_postcode%<br />
						<strong><?php _e( 'Country:', 'wawp' ); ?></strong> %billing_country%<br />
						<strong><?php _e( 'Province:', 'wawp' ); ?></strong> %billing_state%<br />
						<strong><?php _e( 'Email:', 'wawp' ); ?></strong> %billing_email%<br />
						<strong><?php _e( 'Phone:', 'wawp' ); ?></strong> %billing_phone%<br />
						<strong><?php _e( 'Customer Note:', 'wawp' ); ?></strong> %cust_note%<br />
					</div>
					<div class="wsn-body-right">					
						<strong><?php _e( 'SHIP TO DIFFERENT ADDRESS', 'wawp' ); ?></strong><br />
						<strong><?php _e( 'First Name:', 'wawp' ); ?></strong> %shipping_first_name%<br />
						<strong><?php _e( 'Last Name:', 'wawp' ); ?></strong> %shipping_last_name%<br />
						<strong><?php _e( 'Company:', 'wawp' ); ?></strong> %shipping_company%<br />
						<strong><?php _e( 'Address 1:', 'wawp' ); ?></strong> %shipping_address_1%<br />
						<strong><?php _e( 'Address 2:', 'wawp' ); ?></strong> %shipping_address_2%<br />
						<strong><?php _e( 'City:', 'wawp' ); ?></strong> %shipping_city%<br />
						<strong><?php _e( 'Postcode:', 'wawp' ); ?></strong> %shipping_postcode%<br />
						<strong><?php _e( 'Country:', 'wawp' ); ?></strong> %shipping_country%<br />
						<strong><?php _e( 'Province:', 'wawp' ); ?></strong> %shipping_state%<br />
						<br />
						<strong><?php _e( 'PAYMENT &amp; SHIPPING', 'wawp' ); ?></strong><br />
						<strong><?php _e( 'Shipping Method:', 'wawp' ); ?></strong> %shipping_method%<br />
						<strong><?php _e( 'Shipping Cost:', 'wawp' ); ?></strong> %order_shipping%<br />
						<strong><?php _e( 'Shipping Tax:', 'wawp' ); ?></strong> %order_shipping_tax%<br />
						<strong><?php _e( 'Payment Method:', 'wawp' ); ?></strong> %payment_method_title%<br />
						<strong><?php _e( 'Bank Account Info:', 'wawp' ); ?></strong> %bacs_account%<br />
						<br />
						<strong><?php _e( 'INFO', 'wawp' ); ?>INFO</strong><br />
						<strong><?php _e( 'Shop Name:', 'wawp' ); ?></strong> %shop_name%<br />
						<strong><?php _e( 'Order Note:', 'wawp' ); ?></strong> %note%<br />
						<strong><?php _e( 'Meta Key (custom):', 'wawp' ); ?></strong> %meta_key_field%<br />
					</div>
				</div>
				<p style="margin-top: 15px; margin-bottom: 10px;"><strong><?php _e( 'Save Changes', 'wawp' ); ?> <?php _e( 'You can test the service by sending WhatsApp message here:', 'wawp' ); ?></strong></p>
				<form method="post">    
        			<table class="form-table wsn-table">
        			  <tr valign="top">
        				<th scope="row"> <label for="wsn_test_number">
        					<?php _e('To:', 'wawp'); ?>
        				  </label>
        				</th>
        				<td><input id="wsn_test_number" class="regular-text" name="wsn_test_number" type="text"></td>
        			  </tr>	
        			  <tr valign="top">
        				<th scope="row"> <label for="wsn_test_message">
        					<?php _e('Message:', 'wawp'); ?>
        				  </label>
        				</th>
        				<td>
        				    <textarea class="wsn-emoji" id="wsn_test_message" name="wsn_test_message" cols="50" rows="5"></textarea>
        				    <p class="wsn-upload-img">
                                <input type="button" name="upload-btn" class="upload-btn button-secondary" data-id="wsn-test-image" value="Upload Image">
            				    <input type="text" name="wsn_test_image" placeholder="Image URL (Max 1 MB)" class="image_url regular-text wsn-test-image">
                            </p>        				  
        				</td>
        			  </tr>
    			    </table>
    				<p class="submit wsn-submit" style="padding-bottom:0;">
    				  <input type="submit" name="wsn_send_test" class="button-primary"
    						   value="<?php _e( 'Send Message', 'wawp' ); ?>">
    				</p>                    			    
			    </form>
			</div>
		</div>
		<?php
	}
	
	public function setup_info() {
		?>		
		<div class="info-body">
			<p class="head"><a href="https://wawp.net" title="Wawp" target="_blank"><img style="width:90%;" src="<?php echo plugins_url( '/assets/img/logo.png' , __FILE__ ); ?>"></a></p>
		  <div>
			  <form method="post" action="options.php" style="margin-bottom:15px;">
				  <?php settings_fields( 'wsn_storage_instances' ); ?>
				 
				 
				  <label for="wsn_instances[access_token]">
					<?php _e('Access Token:', 'wawp'); ?>
				  </label>
				  <input type="text" id="access_token" name="wsn_instances[access_token]" placeholder="Your Access Token" class="regular-text" value="<?php echo stripcslashes(isset($this->instances['access_token']) ? $this->instances['access_token'] : ''); ?>">				  
				  <label for="wsn_instances[instance_id]">
					<?php _e('Instance ID:', 'wawp'); ?>
				  </label>
				  <input type="text" id="instance_id" name="wsn_instances[instance_id]" placeholder="Your Instance ID" class="regular-text" value="<?php echo stripcslashes(isset($this->instances['instance_id']) ? $this->instances['instance_id'] : ''); ?>">
			  <input type="submit" class="button-primary"
					 value="<?php _e( 'Save Changes', 'wawp' ); ?>" style="margin-top:10px;">  
			  </form>
			  <?php if( isset($this->instances['access_token']) && isset($this->instances['instance_id']) ): ?>
			  <div class="instance-control">
				  <p><strong>Instance Control</strong></p>
				  <a href="#" class="button button-secondary ins-action" data-action="reconnect"><?php _e('Reconnect', 'wawp'); ?></a>
				  <a href="#" class="button button-secondary ins-action" data-action="reboot"><?php _e('Reboot', 'wawp'); ?></a>
				  <a href="#" class="button button-secondary ins-action" data-action="reset"><?php _e('Reset', 'wawp'); ?></a>
				  <a href="#" class="button button-secondary ins-action" data-action="status"><?php _e('Status', 'wawp'); ?></a>
				  <a href="#" class="button button-secondary ins-action" data-action="webhook"><?php _e('Set Webhook', 'wawp'); ?></a>
				  <div class="instance-desc">
					  <strong>Control Description <span>▼</span></strong>
					  <div>
						  <strong><?php _e('Reconnect', 'wawp'); ?></strong><?php _e(': Re-initiate connection from app to WhatsApp Web when lost connection<br><strong>Reboot</strong>: Logout WhatsApp Web and do a fresh scan<br><strong>Reset</strong>: This will logout WhatsApp Web, Change Instance ID, Delete all old instance data<br><strong>Status</strong>: Check connection status. Only works if you have set a profile photo<br><strong>Set Webhook</strong>: Set webhook url to get all return values from Whatsapp, like connection status, incoming message, outgoing message, disconnected, change battery, etc', 'wawp'); ?>
					  </div>
				  </div>	  
			  </div>
			  <div id="control-modal" class="modal"></div>
			  <?php endif; ?>
		  </div>
		</div>
		<?php
	}
	
	public function logs_page() {
        $logger = new woosend_logger();
        $customer_logs = $logger->get_log_file("woosend");
		?>
        <div class="wrap" id="wsn-wrap">
            <h1>
				<?php echo get_admin_page_title(); ?>
                <a href="<?php echo admin_url('admin.php?page=wsn-message-log-v2&clear=1'); ?>" class="button log-clear">Clear Logs</a>
            </h1>
            <div class="form-wrapper">
				<div class="wsn-tab-wrapper">
                    <table class="wp-list-table widefat fixed striped table-view-list posts table-message-logs" style="margin:10px 0;">
                        <thead>
                            <tr>
                                <th><?php _e('Date', 'wawp'); ?></th>
                                <th><?php _e('WhatsApp Number', 'wawp'); ?></th>
                                <th><?php _e('Message', 'wawp'); ?></th>
                                <th><?php _e('Image Attachment', 'wawp'); ?></th>
                                <th><?php _e('Status', 'wawp'); ?></th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php echo $customer_logs; ?>
                        </tbody>   
                    </table>
                    <form method="post" id="resend-form">
                        <input type="hidden" name="wsn_resend_phone">
                        <input type="hidden" name="wsn_resend_message">
                        <input type="hidden" name="wsn_resend_image">
                        <input type="submit" name="wsn_resend_wa" style="display:none;" value="Resend Message">
                    </form>    
				</div>
				<div class="info">
					<?php
						$this->setup_info();	
					?>					
				</div>
			</div>
        </div>
		<?php
	}		
}