<?php
/*
Plugin Name: Automation Web Platform
Version: 1.1.1
Plugin URI: https://wawp.net
Description: Notify your customers about orders and abandoned carts via "WhatsApp" or "WhatsApp Business", for woocommerce system
Author: 101Gen.com
Author URI: https://101gen.com
Text Domain: wawp
Domain Path: /languages
*/

require_once 'wsn-main.php';
require_once 'wsn-ui.php';
require_once 'wsn-logger.php';

$nno = new wsn_main;

function wawp_load_textdomain() {
    load_plugin_textdomain( 'wawp', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
}
add_action( 'plugins_loaded', 'wawp_load_textdomain' );
